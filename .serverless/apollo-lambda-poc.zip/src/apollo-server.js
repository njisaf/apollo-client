/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 625:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(270);
const resolvers_1 = __webpack_require__(981);
const type_defs_1 = __webpack_require__(422);
const establishmentsDB_1 = __importDefault(__webpack_require__(575));
const apolloServer = new apollo_server_lambda_1.ApolloServer({
    resolvers: resolvers_1.resolvers,
    typeDefs: type_defs_1.typeDefs,
    context: ({ event, context }) => {
        console.log('serverless event: ', event);
        console.log('serverless context: ', context);
        return {
            headers: event.headers,
            functionName: context.functionName,
            event,
            context
        };
    },
    dataSources: () => {
        return {
            establishmentsDB: new establishmentsDB_1.default()
        };
    },
    introspection: true,
});
exports.graphqlHandler = apolloServer.createHandler({
    expressGetMiddlewareOptions: {
        cors: {
            origin: '*',
            credentials: true,
        },
    },
});


/***/ }),

/***/ 575:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_datasource_rest_1 = __webpack_require__(797);
const basePath = "l94gia19j0.execute-api.us-east-1.amazonaws.com/prod";
class EstablishmentDB extends apollo_datasource_rest_1.RESTDataSource {
    constructor() {
        super();
        this.baseURL = `https://${basePath}/`;
    }
    willSendRequest(request) {
        request.headers.set("Accept", "*/*");
        request.headers.set("content-type", "application/json");
    }
    getEstablishment(id) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('id: ', id);
            return yield this.get(`establishment?id=${encodeURIComponent(id)}`);
        });
    }
    createEstablishment(id, name) {
        return __awaiter(this, void 0, void 0, function* () {
            const postRes = yield this.post("establishment", {
                id,
                name
            });
            console.log('postRes: ', postRes);
            return postRes.Item;
        });
    }
}
exports["default"] = EstablishmentDB;


/***/ }),

/***/ 824:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.environment = void 0;
exports.environment = {
    secretMessage: process.env.SECRET_MESSAGE,
    apiToken: process.env.API_TOKEN,
};


/***/ }),

/***/ 981:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolvers = void 0;
const environment_1 = __webpack_require__(824);
exports.resolvers = {
    Query: {
        testMessage: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            return `${environment_1.environment.secretMessage}. Your message is ${args.search}`;
        }),
        getEstablishment: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            console.log('args: ', args);
            return yield context.dataSources.establishmentsDB.getEstablishment(args.id);
        }),
        getAllEstablishments: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            return yield context.dataSources.establishmentsDB.getAllEstablishments();
        }),
    },
    Mutation: {
        createEstablishment: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            return yield context.dataSources.establishmentsDB.createEstablishment(args.id, args.name);
        })
    }
};


/***/ }),

/***/ 422:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.typeDefs = void 0;
const apollo_server_lambda_1 = __webpack_require__(270);
exports.typeDefs = (0, apollo_server_lambda_1.gql) `
  type Establishment {
    id: String!,
    name: String!
  }
  scalar Json
  type Query {
    testMessage: String!,
    getEstablishment(id: String!): Establishment,
    getAllEstablishments: [Establishment],
  }
  type Mutation {
    createEstablishment(id: String!, name: String!): Establishment
  }
`;


/***/ }),

/***/ 797:
/***/ ((module) => {

module.exports = require("apollo-datasource-rest");

/***/ }),

/***/ 270:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(625);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2Fwb2xsby1zZXJ2ZXIuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUNBO0FBR0E7QUFDQTtBQUVBO0FBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQ0E7QUFHQTtBQUVBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFJQTtBQUVBOztBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBRUE7O0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBRUE7Ozs7Ozs7Ozs7O0FDcENBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1JBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDcEJBO0FBRUE7Ozs7Ozs7Ozs7Ozs7O0FBY0E7Ozs7Ozs7O0FDaEJBOzs7Ozs7O0FDQUE7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FFdkJBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci8uL3NyYy9hcG9sbG8tc2VydmVyLnRzIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvLi9zcmMvZGF0YXNvdXJjZXMvZXN0YWJsaXNobWVudHNEQi50cyIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyLy4vc3JjL2Vudmlyb25tZW50LnRzIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvLi9zcmMvcmVzb2x2ZXJzLnRzIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvLi9zcmMvdHlwZS1kZWZzLnRzIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvZXh0ZXJuYWwgY29tbW9uanMgXCJhcG9sbG8tZGF0YXNvdXJjZS1yZXN0XCIiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci9leHRlcm5hbCBjb21tb25qcyBcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyL3dlYnBhY2svYmVmb3JlLXN0YXJ0dXAiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci93ZWJwYWNrL3N0YXJ0dXAiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiXG5pbXBvcnQgeyBBcG9sbG9TZXJ2ZXIgfSBmcm9tICdhcG9sbG8tc2VydmVyLWxhbWJkYSc7XG4vLyBpbXBvcnQgeyBEb2N1bWVudENsaWVudCB9IGZyb20gJ2F3cy1zZGsvY2xpZW50cy9keW5hbW9kYic7XG5cbmltcG9ydCB7IHJlc29sdmVycyB9IGZyb20gJy4vcmVzb2x2ZXJzJztcbmltcG9ydCB7IHR5cGVEZWZzIH0gZnJvbSAnLi90eXBlLWRlZnMnO1xuXG5pbXBvcnQgRXN0YWJsaXNobWVudHNEQiBmcm9tICcuL2RhdGFzb3VyY2VzL2VzdGFibGlzaG1lbnRzREInO1xuXG4vLyBjb25zdCBjbGllbnQ6IERvY3VtZW50Q2xpZW50ID0gbmV3IERvY3VtZW50Q2xpZW50KHtcbi8vICAgICBhcGlWZXJzaW9uOiAnbGF0ZXN0Jyxcbi8vICAgICByZWdpb246ICd1cy1lYXN0LTEnLFxuLy8gfSk7XG5cblxuY29uc3QgYXBvbGxvU2VydmVyID0gbmV3IEFwb2xsb1NlcnZlcih7XG4gICAgcmVzb2x2ZXJzLFxuICAgIHR5cGVEZWZzLFxuICAgIGNvbnRleHQ6ICh7ZXZlbnQsIGNvbnRleHR9KSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdzZXJ2ZXJsZXNzIGV2ZW50OiAnLCBldmVudCk7XG4gICAgICAgIGNvbnNvbGUubG9nKCdzZXJ2ZXJsZXNzIGNvbnRleHQ6ICcsIGNvbnRleHQpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGVhZGVyczogZXZlbnQuaGVhZGVycyxcbiAgICAgICAgICAgIGZ1bmN0aW9uTmFtZTogY29udGV4dC5mdW5jdGlvbk5hbWUsXG4gICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgIGNvbnRleHRcbiAgICAgICAgfVxuICAgIH0sXG4gICAgZGF0YVNvdXJjZXM6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGVzdGFibGlzaG1lbnRzREI6IG5ldyBFc3RhYmxpc2htZW50c0RCKClcbiAgICAgICAgfVxuICAgIH0sXG4gICAgaW50cm9zcGVjdGlvbjogdHJ1ZSxcbn0pO1xuXG5leHBvcnQgY29uc3QgZ3JhcGhxbEhhbmRsZXIgPSBhcG9sbG9TZXJ2ZXIuY3JlYXRlSGFuZGxlcih7XG4gICAgZXhwcmVzc0dldE1pZGRsZXdhcmVPcHRpb25zOiB7XG4gICAgICAgIGNvcnM6IHtcbiAgICAgICAgICAgIG9yaWdpbjogJyonLFxuICAgICAgICAgICAgY3JlZGVudGlhbHM6IHRydWUsXG4gICAgICAgIH0sXG4gICAgfSxcbn0pOyIsImltcG9ydCB7IFJFU1REYXRhU291cmNlLCBSZXF1ZXN0T3B0aW9ucyB9IGZyb20gXCJhcG9sbG8tZGF0YXNvdXJjZS1yZXN0XCI7XG5pbXBvcnQgeyBlbnZpcm9ubWVudCB9IGZyb20gJy4uL2Vudmlyb25tZW50JztcblxuY29uc3QgYmFzZVBhdGggPSBcImw5NGdpYTE5ajAuZXhlY3V0ZS1hcGkudXMtZWFzdC0xLmFtYXpvbmF3cy5jb20vcHJvZFwiO1xuXG5jbGFzcyBFc3RhYmxpc2htZW50REIgZXh0ZW5kcyBSRVNURGF0YVNvdXJjZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIC8vIEFsd2F5cyBjYWxsIHN1cGVyKClcbiAgICBzdXBlcigpO1xuICAgIC8vIFNldHMgdGhlIGJhc2UgVVJMIGZvciB0aGUgUkVTVCBBUElcbiAgICB0aGlzLmJhc2VVUkwgPSBgaHR0cHM6Ly8ke2Jhc2VQYXRofS9gO1xuICB9XG4gIHdpbGxTZW5kUmVxdWVzdChyZXF1ZXN0OiBSZXF1ZXN0T3B0aW9ucykge1xuICAgIHJlcXVlc3QuaGVhZGVycy5zZXQoXG4gICAgICBcIkFjY2VwdFwiLFxuICAgICAgXCIqLypcIlxuICAgICk7XG4gICAgcmVxdWVzdC5oZWFkZXJzLnNldChcbiAgICAgIFwiY29udGVudC10eXBlXCIsXG4gICAgICBcImFwcGxpY2F0aW9uL2pzb25cIlxuICAgICk7XG4gIH1cblxuICBhc3luYyBnZXRFc3RhYmxpc2htZW50KGlkOiBzdHJpbmcpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdpZDogJywgaWQpO1xuICAgIHJldHVybiBhd2FpdCB0aGlzLmdldChgZXN0YWJsaXNobWVudD9pZD0ke2VuY29kZVVSSUNvbXBvbmVudChpZCl9YCk7XG4gIH1cblxuICBhc3luYyBjcmVhdGVFc3RhYmxpc2htZW50KGlkOiBzdHJpbmcsIG5hbWU6IHN0cmluZykge1xuICAgICAgY29uc3QgcG9zdFJlcyA9IGF3YWl0IHRoaXMucG9zdChcbiAgICAgICAgICBcImVzdGFibGlzaG1lbnRcIixcbiAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkLFxuICAgICAgICAgICAgICBuYW1lXG4gICAgICAgICAgICB9XG4gICAgICAgIClcbiAgICBjb25zb2xlLmxvZygncG9zdFJlczogJywgcG9zdFJlcyk7XG4gICAgcmV0dXJuIHBvc3RSZXMuSXRlbTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBFc3RhYmxpc2htZW50REI7XG4iLCJ0eXBlIEVudmlyb25tZW50ID0ge1xuICAgIHNlY3JldE1lc3NhZ2U6IHN0cmluZyxcbiAgICBhcGlUb2tlbjogc3RyaW5nXG59O1xuXG5leHBvcnQgY29uc3QgZW52aXJvbm1lbnQ6IEVudmlyb25tZW50ID0ge1xuICAgIHNlY3JldE1lc3NhZ2U6IHByb2Nlc3MuZW52LlNFQ1JFVF9NRVNTQUdFIGFzIHN0cmluZyxcbiAgICBhcGlUb2tlbjogcHJvY2Vzcy5lbnYuQVBJX1RPS0VOIGFzIHN0cmluZyxcbn07IiwiaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICcuL2Vudmlyb25tZW50JztcblxuZXhwb3J0IGNvbnN0IHJlc29sdmVycyA9IHtcbiAgUXVlcnk6IHtcbiAgICB0ZXN0TWVzc2FnZTogYXN5bmMgKHBhcmVudDogYW55LCBhcmdzOiBhbnksIGNvbnRleHQ6IGFueSwgaW5mbzogYW55KSA9PiB7XG4gICAgICByZXR1cm4gYCR7ZW52aXJvbm1lbnQuc2VjcmV0TWVzc2FnZX0uIFlvdXIgbWVzc2FnZSBpcyAke2FyZ3Muc2VhcmNofWA7XG4gICAgfSxcbiAgICBnZXRFc3RhYmxpc2htZW50OiBhc3luYyAocGFyZW50OiBhbnksIGFyZ3M6IGFueSwgY29udGV4dDogYW55LCBpbmZvOiBhbnkpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKCdhcmdzOiAnLCBhcmdzKTtcbiAgICAgIHJldHVybiBhd2FpdCBjb250ZXh0LmRhdGFTb3VyY2VzLmVzdGFibGlzaG1lbnRzREIuZ2V0RXN0YWJsaXNobWVudChhcmdzLmlkKTtcbiAgICB9LFxuICAgIGdldEFsbEVzdGFibGlzaG1lbnRzOiBhc3luYyAocGFyZW50OiBhbnksIGFyZ3M6IGFueSwgY29udGV4dDogYW55LCBpbmZvOiBhbnkpID0+IHtcbiAgICAgIHJldHVybiBhd2FpdCBjb250ZXh0LmRhdGFTb3VyY2VzLmVzdGFibGlzaG1lbnRzREIuZ2V0QWxsRXN0YWJsaXNobWVudHMoKTtcbiAgICB9LFxuICB9LFxuICBNdXRhdGlvbjoge1xuICAgIGNyZWF0ZUVzdGFibGlzaG1lbnQ6IGFzeW5jIChwYXJlbnQ6IGFueSwgYXJnczogYW55LCBjb250ZXh0OiBhbnksIGluZm86IGFueSkgPT4ge1xuICAgICAgcmV0dXJuIGF3YWl0IGNvbnRleHQuZGF0YVNvdXJjZXMuZXN0YWJsaXNobWVudHNEQi5jcmVhdGVFc3RhYmxpc2htZW50KGFyZ3MuaWQsIGFyZ3MubmFtZSk7XG4gICAgfVxuICB9XG59OyIsImltcG9ydCB7IGdxbCB9IGZyb20gXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiO1xuXG5leHBvcnQgY29uc3QgdHlwZURlZnMgPSBncWxgXG4gIHR5cGUgRXN0YWJsaXNobWVudCB7XG4gICAgaWQ6IFN0cmluZyEsXG4gICAgbmFtZTogU3RyaW5nIVxuICB9XG4gIHNjYWxhciBKc29uXG4gIHR5cGUgUXVlcnkge1xuICAgIHRlc3RNZXNzYWdlOiBTdHJpbmchLFxuICAgIGdldEVzdGFibGlzaG1lbnQoaWQ6IFN0cmluZyEpOiBFc3RhYmxpc2htZW50LFxuICAgIGdldEFsbEVzdGFibGlzaG1lbnRzOiBbRXN0YWJsaXNobWVudF0sXG4gIH1cbiAgdHlwZSBNdXRhdGlvbiB7XG4gICAgY3JlYXRlRXN0YWJsaXNobWVudChpZDogU3RyaW5nISwgbmFtZTogU3RyaW5nISk6IEVzdGFibGlzaG1lbnRcbiAgfVxuYDtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImFwb2xsby1kYXRhc291cmNlLXJlc3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYXBvbGxvLXNlcnZlci1sYW1iZGFcIik7IiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgaXMgcmVmZXJlbmNlZCBieSBvdGhlciBtb2R1bGVzIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXyg2MjUpO1xuIiwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9