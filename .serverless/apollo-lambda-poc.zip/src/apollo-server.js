/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 625:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(270);
const resolvers_1 = __webpack_require__(981);
const type_defs_1 = __webpack_require__(422);
const moviesAPI_1 = __importDefault(__webpack_require__(140));
const imdbAPI_1 = __importDefault(__webpack_require__(84));
const apolloServer = new apollo_server_lambda_1.ApolloServer({
    resolvers: resolvers_1.resolvers,
    typeDefs: type_defs_1.typeDefs,
    dataSources: () => {
        return {
            moviesAPI: new moviesAPI_1.default(),
            imdbAPI: new imdbAPI_1.default()
        };
    }
});
exports.graphqlHandler = apolloServer.createHandler();


/***/ }),

/***/ 824:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.environment = void 0;
exports.environment = {
    secretMessage: process.env.SECRET_MESSAGE,
    apiToken: process.env.API_TOKEN,
};


/***/ }),

/***/ 84:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_datasource_rest_1 = __webpack_require__(797);
const environment_1 = __webpack_require__(824);
const basePath = "imdb8.p.rapidapi.com";
class ImdbAPI extends apollo_datasource_rest_1.RESTDataSource {
    constructor() {
        super();
        this.baseURL = `https://${basePath}/`;
    }
    willSendRequest(request) {
        request.headers.set("x-rapidapi-host", basePath);
        request.headers.set("x-rapidapi-key", environment_1.environment.apiToken);
    }
    getImdb(search) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("search: ", search);
            return this.get(`title/find/?q=${encodeURIComponent(search)}`);
        });
    }
}
exports["default"] = ImdbAPI;


/***/ }),

/***/ 140:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_datasource_rest_1 = __webpack_require__(797);
const environment_1 = __webpack_require__(824);
const basePath = "movie-database-imdb-alternative.p.rapidapi.com";
class MoviesAPI extends apollo_datasource_rest_1.RESTDataSource {
    constructor() {
        super();
        this.baseURL = `https://${basePath}/`;
    }
    willSendRequest(request) {
        request.headers.set('x-rapidapi-host', basePath);
        request.headers.set('x-rapidapi-key', environment_1.environment.apiToken);
    }
    getMoviesdb(search) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('search: ', search);
            return this.get(`?s=${encodeURIComponent(search)}&r=json&page=1`);
        });
    }
}
exports["default"] = MoviesAPI;


/***/ }),

/***/ 981:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolvers = void 0;
const environment_1 = __webpack_require__(824);
const util_dynamodb_1 = __webpack_require__(85);
const client_dynamodb_1 = __webpack_require__(317);
const client = new client_dynamodb_1.DynamoDBClient({ region: "us-east-1" });
const getHistory = () => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const params = {
        TableName: "search_history",
    };
    try {
        const results = yield client.send(new client_dynamodb_1.ScanCommand(params));
        const history = [];
        (_a = results === null || results === void 0 ? void 0 : results.Items) === null || _a === void 0 ? void 0 : _a.forEach((item) => {
            history.push((0, util_dynamodb_1.unmarshall)(item));
        });
        console.log('history: ', history);
        return history;
    }
    catch (err) {
        console.error(err);
        return err;
    }
});
exports.resolvers = {
    Query: {
        testMessage: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            console.log('args: ', args);
            return `${environment_1.environment.secretMessage}. Your message is ${args.search}`;
        }),
        imdb: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            console.log('args: ', args);
            return context.dataSources.imdbAPI.getImdb(args.search);
        }),
        moviesdb: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            console.log('args: ', args);
            return context.dataSources.moviesAPI.getMoviesdb(args.search);
        }),
        history: () => __awaiter(void 0, void 0, void 0, function* () {
            return getHistory();
        })
    },
};


/***/ }),

/***/ 422:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.typeDefs = void 0;
const apollo_server_lambda_1 = __webpack_require__(270);
exports.typeDefs = (0, apollo_server_lambda_1.gql) `
  type MovieResult {
    Title: String,
    Year: String,
    imdbId: String,
    Type: String,
    Poster: String
  }
  type ImdbImg {
    id: String,
    url: String,
    height: Int,
    width: Int
  }
  type ImdbRole {
    character: String,
    characterId: String
  }
  type ImdbActor {
    disambiguation: String,
    id: String,
    legacyNameText: String,
    name: String,
    category: String,
    characters: [String],
    endYear: Int,
    episodeCount: Int,
    roles: [ImdbRole],
    startYear: String
  }
  type ImdbResult {
    id: String,
    image: ImdbImg,
    runningTimInMinutes: Int,
    nextEpisode: String,
    numberOfEpisodes: Int,
    seriesEndYear: Int,
    seriesStartYear: Int,
    title: String,
    titleType: String,
    year: Int,
    principals: [ImdbActor]
  }
  type Imdb {
    query: String,
    results: [ImdbResult]
  }
  type Movies {
    Search: [MovieResult],
    totalResults: Int,
    Response: Boolean
  }
  type HistoryObject {
    id: String
    value: String
  }
  scalar Json
  type Query {
    testMessage: String!,
    imdb(search: String): Imdb
    moviesdb(search: String): Movies
    history: [HistoryObject]
  }
`;


/***/ }),

/***/ 317:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-dynamodb");

/***/ }),

/***/ 85:
/***/ ((module) => {

module.exports = require("@aws-sdk/util-dynamodb");

/***/ }),

/***/ 797:
/***/ ((module) => {

module.exports = require("apollo-datasource-rest");

/***/ }),

/***/ 270:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(625);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2Fwb2xsby1zZXJ2ZXIuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUNBO0FBR0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBOzs7Ozs7Ozs7OztBQ25CQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1JBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFJQTtBQUVBOztBQUNBO0FBRUE7QUFDQTtBQUFBO0FBQ0E7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlCQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7QUFDQTtBQUVBO0FBQ0E7QUFBQTtBQUNBO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEJBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQzNDQTtBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUErREE7Ozs7Ozs7O0FDakVBOzs7Ozs7O0FDQUE7Ozs7Ozs7QUNBQTs7Ozs7OztBQ0FBOzs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBRXZCQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvLi9zcmMvYXBvbGxvLXNlcnZlci50cyIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyLy4vc3JjL2Vudmlyb25tZW50LnRzIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvLi9zcmMvaW1kYkFQSS50cyIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyLy4vc3JjL21vdmllc0FQSS50cyIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyLy4vc3JjL3Jlc29sdmVycy50cyIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyLy4vc3JjL3R5cGUtZGVmcy50cyIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyL2V4dGVybmFsIGNvbW1vbmpzIFwiQGF3cy1zZGsvY2xpZW50LWR5bmFtb2RiXCIiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci9leHRlcm5hbCBjb21tb25qcyBcIkBhd3Mtc2RrL3V0aWwtZHluYW1vZGJcIiIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyL2V4dGVybmFsIGNvbW1vbmpzIFwiYXBvbGxvLWRhdGFzb3VyY2UtcmVzdFwiIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvZXh0ZXJuYWwgY29tbW9uanMgXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci93ZWJwYWNrL2JlZm9yZS1zdGFydHVwIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvd2VicGFjay9hZnRlci1zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbIlxuaW1wb3J0IHsgQXBvbGxvU2VydmVyIH0gZnJvbSAnYXBvbGxvLXNlcnZlci1sYW1iZGEnO1xuXG5cbmltcG9ydCB7IHJlc29sdmVycyB9IGZyb20gJy4vcmVzb2x2ZXJzJztcbmltcG9ydCB7IHR5cGVEZWZzIH0gZnJvbSAnLi90eXBlLWRlZnMnO1xuXG5pbXBvcnQgTW92aWVzQVBJIGZyb20gJy4vbW92aWVzQVBJJztcbmltcG9ydCBJbWRiQVBJIGZyb20gJy4vaW1kYkFQSSc7XG5cbmNvbnN0IGFwb2xsb1NlcnZlciA9IG5ldyBBcG9sbG9TZXJ2ZXIoe1xuICAgIHJlc29sdmVycyxcbiAgICB0eXBlRGVmcyxcbiAgICAvLyBjb250ZXh0OiAoe3JlcX0pID0+IHtcbiAgICAgICAgXG4gICAgLy8gfSxcbiAgICBkYXRhU291cmNlczogKCkgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbW92aWVzQVBJOiBuZXcgTW92aWVzQVBJKCksXG4gICAgICAgICAgICBpbWRiQVBJOiBuZXcgSW1kYkFQSSgpXG4gICAgICAgIH1cbiAgICB9XG59KTtcblxuZXhwb3J0IGNvbnN0IGdyYXBocWxIYW5kbGVyID0gYXBvbGxvU2VydmVyLmNyZWF0ZUhhbmRsZXIoKTsiLCJ0eXBlIEVudmlyb25tZW50ID0ge1xuICAgIHNlY3JldE1lc3NhZ2U6IHN0cmluZyxcbiAgICBhcGlUb2tlbjogc3RyaW5nXG59O1xuXG5leHBvcnQgY29uc3QgZW52aXJvbm1lbnQ6IEVudmlyb25tZW50ID0ge1xuICAgIHNlY3JldE1lc3NhZ2U6IHByb2Nlc3MuZW52LlNFQ1JFVF9NRVNTQUdFIGFzIHN0cmluZyxcbiAgICBhcGlUb2tlbjogcHJvY2Vzcy5lbnYuQVBJX1RPS0VOIGFzIHN0cmluZyxcbn07IiwiaW1wb3J0IHsgUkVTVERhdGFTb3VyY2UsIFJlcXVlc3RPcHRpb25zIH0gZnJvbSBcImFwb2xsby1kYXRhc291cmNlLXJlc3RcIjtcbmltcG9ydCB7IGVudmlyb25tZW50IH0gZnJvbSAnLi9lbnZpcm9ubWVudCc7XG5cbmNvbnN0IGJhc2VQYXRoID0gXCJpbWRiOC5wLnJhcGlkYXBpLmNvbVwiO1xuXG5jbGFzcyBJbWRiQVBJIGV4dGVuZHMgUkVTVERhdGFTb3VyY2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICAvLyBBbHdheXMgY2FsbCBzdXBlcigpXG4gICAgc3VwZXIoKTtcbiAgICAvLyBTZXRzIHRoZSBiYXNlIFVSTCBmb3IgdGhlIFJFU1QgQVBJXG4gICAgdGhpcy5iYXNlVVJMID0gYGh0dHBzOi8vJHtiYXNlUGF0aH0vYDtcbiAgfVxuICB3aWxsU2VuZFJlcXVlc3QocmVxdWVzdDogUmVxdWVzdE9wdGlvbnMpIHtcbiAgICByZXF1ZXN0LmhlYWRlcnMuc2V0KFxuICAgICAgXCJ4LXJhcGlkYXBpLWhvc3RcIixcbiAgICAgIGJhc2VQYXRoXG4gICAgKTtcbiAgICByZXF1ZXN0LmhlYWRlcnMuc2V0KFxuICAgICAgXCJ4LXJhcGlkYXBpLWtleVwiLFxuICAgICAgZW52aXJvbm1lbnQuYXBpVG9rZW5cbiAgICApO1xuICB9XG5cbiAgYXN5bmMgZ2V0SW1kYihzZWFyY2g6IHN0cmluZykge1xuICAgIGNvbnNvbGUubG9nKFwic2VhcmNoOiBcIiwgc2VhcmNoKTtcbiAgICAvLyBTZW5kIGEgR0VUIHJlcXVlc3QgdG8gdGhlIHNwZWNpZmllZCBlbmRwb2ludFxuICAgIHJldHVybiB0aGlzLmdldChgdGl0bGUvZmluZC8/cT0ke2VuY29kZVVSSUNvbXBvbmVudChzZWFyY2gpfWApO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IEltZGJBUEk7XG4iLCJpbXBvcnQgeyBSRVNURGF0YVNvdXJjZSwgUmVxdWVzdE9wdGlvbnMgfSBmcm9tICdhcG9sbG8tZGF0YXNvdXJjZS1yZXN0JztcbmltcG9ydCB7IGVudmlyb25tZW50IH0gZnJvbSAnLi9lbnZpcm9ubWVudCc7XG5cbmNvbnN0IGJhc2VQYXRoID0gXCJtb3ZpZS1kYXRhYmFzZS1pbWRiLWFsdGVybmF0aXZlLnAucmFwaWRhcGkuY29tXCJcblxuY2xhc3MgTW92aWVzQVBJIGV4dGVuZHMgUkVTVERhdGFTb3VyY2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICAvLyBBbHdheXMgY2FsbCBzdXBlcigpXG4gICAgc3VwZXIoKTtcbiAgICAvLyBTZXRzIHRoZSBiYXNlIFVSTCBmb3IgdGhlIFJFU1QgQVBJXG4gICAgdGhpcy5iYXNlVVJMID0gYGh0dHBzOi8vJHtiYXNlUGF0aH0vYDtcbiAgfVxuICB3aWxsU2VuZFJlcXVlc3QocmVxdWVzdDogUmVxdWVzdE9wdGlvbnMpIHtcbiAgICByZXF1ZXN0LmhlYWRlcnMuc2V0KCd4LXJhcGlkYXBpLWhvc3QnLCBiYXNlUGF0aCk7XG4gICAgcmVxdWVzdC5oZWFkZXJzLnNldCgneC1yYXBpZGFwaS1rZXknLCBlbnZpcm9ubWVudC5hcGlUb2tlbik7XG4gIH1cblxuICBhc3luYyBnZXRNb3ZpZXNkYihzZWFyY2g6IHN0cmluZykge1xuICAgIGNvbnNvbGUubG9nKCdzZWFyY2g6ICcsIHNlYXJjaCk7XG4gICAgLy8gU2VuZCBhIEdFVCByZXF1ZXN0IHRvIHRoZSBzcGVjaWZpZWQgZW5kcG9pbnRcbiAgICByZXR1cm4gdGhpcy5nZXQoYD9zPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHNlYXJjaCl9JnI9anNvbiZwYWdlPTFgKTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBNb3ZpZXNBUEk7IiwiaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICcuL2Vudmlyb25tZW50JztcbmltcG9ydCB7IHVubWFyc2hhbGwgfSBmcm9tIFwiQGF3cy1zZGsvdXRpbC1keW5hbW9kYlwiO1xuaW1wb3J0IHsgRHluYW1vREJDbGllbnQsIFNjYW5Db21tYW5kIH0gZnJvbSBcIkBhd3Mtc2RrL2NsaWVudC1keW5hbW9kYlwiO1xuXG5jb25zdCBjbGllbnQgPSBuZXcgRHluYW1vREJDbGllbnQoeyByZWdpb246IFwidXMtZWFzdC0xXCIgfSk7XG5cbmNvbnN0IGdldEhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XG4gIGNvbnN0IHBhcmFtcyA9IHtcbiAgICBUYWJsZU5hbWU6IFwic2VhcmNoX2hpc3RvcnlcIixcbiAgfTtcblxuICB0cnkge1xuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBjbGllbnQuc2VuZChuZXcgU2NhbkNvbW1hbmQocGFyYW1zKSk7XG4gICAgY29uc3QgaGlzdG9yeTogYW55ID0gW107XG4gICAgcmVzdWx0cz8uSXRlbXM/LmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgIGhpc3RvcnkucHVzaCh1bm1hcnNoYWxsKGl0ZW0pKTtcbiAgICB9KTtcbiAgICBjb25zb2xlLmxvZygnaGlzdG9yeTogJywgaGlzdG9yeSk7XG4gICAgcmV0dXJuIGhpc3Rvcnk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICByZXR1cm4gZXJyO1xuICB9XG59O1xuXG5leHBvcnQgY29uc3QgcmVzb2x2ZXJzID0ge1xuICBRdWVyeToge1xuICAgIHRlc3RNZXNzYWdlOiBhc3luYyAocGFyZW50OiBhbnksIGFyZ3M6IGFueSwgY29udGV4dDogYW55LCBpbmZvOiBhbnkpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKCdhcmdzOiAnLCBhcmdzKTtcbiAgICAgIHJldHVybiBgJHtlbnZpcm9ubWVudC5zZWNyZXRNZXNzYWdlfS4gWW91ciBtZXNzYWdlIGlzICR7YXJncy5zZWFyY2h9YDtcbiAgICB9LFxuICAgIGltZGI6IGFzeW5jIChwYXJlbnQ6IGFueSwgYXJnczogYW55LCBjb250ZXh0OiBhbnksIGluZm86IGFueSkgPT4ge1xuICAgICAgY29uc29sZS5sb2coJ2FyZ3M6ICcsIGFyZ3MpO1xuICAgICAgcmV0dXJuIGNvbnRleHQuZGF0YVNvdXJjZXMuaW1kYkFQSS5nZXRJbWRiKGFyZ3Muc2VhcmNoKTtcbiAgICB9LFxuICAgIG1vdmllc2RiOiBhc3luYyAocGFyZW50OiBhbnksIGFyZ3M6IGFueSwgY29udGV4dDogYW55LCBpbmZvOiBhbnkpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKCdhcmdzOiAnLCBhcmdzKTtcbiAgICAgIHJldHVybiBjb250ZXh0LmRhdGFTb3VyY2VzLm1vdmllc0FQSS5nZXRNb3ZpZXNkYihhcmdzLnNlYXJjaCk7XG4gICAgfSxcbiAgICBoaXN0b3J5OiBhc3luYyAoKSA9PiB7XG4gICAgICByZXR1cm4gZ2V0SGlzdG9yeSgpO1xuICAgIH1cbiAgfSxcbn07IiwiaW1wb3J0IHsgZ3FsIH0gZnJvbSBcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCI7XG5cbmV4cG9ydCBjb25zdCB0eXBlRGVmcyA9IGdxbGBcbiAgdHlwZSBNb3ZpZVJlc3VsdCB7XG4gICAgVGl0bGU6IFN0cmluZyxcbiAgICBZZWFyOiBTdHJpbmcsXG4gICAgaW1kYklkOiBTdHJpbmcsXG4gICAgVHlwZTogU3RyaW5nLFxuICAgIFBvc3RlcjogU3RyaW5nXG4gIH1cbiAgdHlwZSBJbWRiSW1nIHtcbiAgICBpZDogU3RyaW5nLFxuICAgIHVybDogU3RyaW5nLFxuICAgIGhlaWdodDogSW50LFxuICAgIHdpZHRoOiBJbnRcbiAgfVxuICB0eXBlIEltZGJSb2xlIHtcbiAgICBjaGFyYWN0ZXI6IFN0cmluZyxcbiAgICBjaGFyYWN0ZXJJZDogU3RyaW5nXG4gIH1cbiAgdHlwZSBJbWRiQWN0b3Ige1xuICAgIGRpc2FtYmlndWF0aW9uOiBTdHJpbmcsXG4gICAgaWQ6IFN0cmluZyxcbiAgICBsZWdhY3lOYW1lVGV4dDogU3RyaW5nLFxuICAgIG5hbWU6IFN0cmluZyxcbiAgICBjYXRlZ29yeTogU3RyaW5nLFxuICAgIGNoYXJhY3RlcnM6IFtTdHJpbmddLFxuICAgIGVuZFllYXI6IEludCxcbiAgICBlcGlzb2RlQ291bnQ6IEludCxcbiAgICByb2xlczogW0ltZGJSb2xlXSxcbiAgICBzdGFydFllYXI6IFN0cmluZ1xuICB9XG4gIHR5cGUgSW1kYlJlc3VsdCB7XG4gICAgaWQ6IFN0cmluZyxcbiAgICBpbWFnZTogSW1kYkltZyxcbiAgICBydW5uaW5nVGltSW5NaW51dGVzOiBJbnQsXG4gICAgbmV4dEVwaXNvZGU6IFN0cmluZyxcbiAgICBudW1iZXJPZkVwaXNvZGVzOiBJbnQsXG4gICAgc2VyaWVzRW5kWWVhcjogSW50LFxuICAgIHNlcmllc1N0YXJ0WWVhcjogSW50LFxuICAgIHRpdGxlOiBTdHJpbmcsXG4gICAgdGl0bGVUeXBlOiBTdHJpbmcsXG4gICAgeWVhcjogSW50LFxuICAgIHByaW5jaXBhbHM6IFtJbWRiQWN0b3JdXG4gIH1cbiAgdHlwZSBJbWRiIHtcbiAgICBxdWVyeTogU3RyaW5nLFxuICAgIHJlc3VsdHM6IFtJbWRiUmVzdWx0XVxuICB9XG4gIHR5cGUgTW92aWVzIHtcbiAgICBTZWFyY2g6IFtNb3ZpZVJlc3VsdF0sXG4gICAgdG90YWxSZXN1bHRzOiBJbnQsXG4gICAgUmVzcG9uc2U6IEJvb2xlYW5cbiAgfVxuICB0eXBlIEhpc3RvcnlPYmplY3Qge1xuICAgIGlkOiBTdHJpbmdcbiAgICB2YWx1ZTogU3RyaW5nXG4gIH1cbiAgc2NhbGFyIEpzb25cbiAgdHlwZSBRdWVyeSB7XG4gICAgdGVzdE1lc3NhZ2U6IFN0cmluZyEsXG4gICAgaW1kYihzZWFyY2g6IFN0cmluZyk6IEltZGJcbiAgICBtb3ZpZXNkYihzZWFyY2g6IFN0cmluZyk6IE1vdmllc1xuICAgIGhpc3Rvcnk6IFtIaXN0b3J5T2JqZWN0XVxuICB9XG5gO1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGF3cy1zZGsvY2xpZW50LWR5bmFtb2RiXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBhd3Mtc2RrL3V0aWwtZHluYW1vZGJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYXBvbGxvLWRhdGFzb3VyY2UtcmVzdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiKTsiLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBpcyByZWZlcmVuY2VkIGJ5IG90aGVyIG1vZHVsZXMgc28gaXQgY2FuJ3QgYmUgaW5saW5lZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDYyNSk7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=