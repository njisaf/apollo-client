/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 625:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(270);
const resolvers_1 = __webpack_require__(981);
const type_defs_1 = __webpack_require__(422);
const establishmentsDB_1 = __importDefault(__webpack_require__(575));
const paths = {
    graphQL: "/graphql",
    establishment: "/establishment",
};
const apolloServer = new apollo_server_lambda_1.ApolloServer({
    resolvers: resolvers_1.resolvers,
    typeDefs: type_defs_1.typeDefs,
    context: ({ event, context }) => {
        console.log("server event: ", event);
        console.log("server context: ", context);
        return {
            headers: event.headers,
            functionName: context.functionName,
            event,
            context,
        };
    },
    dataSources: () => {
        return {
            establishmentsDB: new establishmentsDB_1.default(),
        };
    },
    introspection: true,
});
const apolloHandler = apolloServer.createHandler({
    expressGetMiddlewareOptions: {
        cors: {
            origin: "*",
            credentials: true,
        },
    },
});
const graphqlHandler = (event, context, callback) => {
    console.log("Request event", event);
    console.log("Request context: ", context);
    let resBody, variables, newEvent;
    switch (true) {
        case event.httpMethod === "GET" && event.path === paths.establishment:
            const query = `
                query GetEstablishment($getEstablishmentId: String!) {
                    getEstablishment(dba_name: $getEstablishmentId) {
                        dba_name
                        legal_name
                        addresses {
                            address_id
                            address_type
                            address_state
                        }
                    }
                }
                `;
            variables = {
                getEstablishmentId: event.queryStringParameters.dba_name,
            };
            resBody = JSON.stringify({
                query,
                variables,
            });
            newEvent = Object.assign(event, {
                body: resBody,
                requestContext: context,
                resource: "/graphql",
                path: "/graphql",
                httpMethod: "POST",
                headers: {
                    "Accept": "*/*",
                    "content-type": "application/json",
                },
            });
            break;
        case event.httpMethod === "POST" && event.path === paths.establishment:
            const mutation = `
                mutation CreateEstablishment($newEstablishment: EstablishmentInput) {
                    createEstablishment(establishment: $newEstablishment) {
                        dba_name
                        legal_name
                        addresses {
                            address_id
                            address_type
                            address_state
                        }
                    }
                }`;
            const body = JSON.parse(event.body);
            variables = {
                newEstablishment: body
            };
            resBody = JSON.stringify({
                query: mutation,
                variables,
            });
            newEvent = Object.assign(event, {
                body: resBody,
                requestContext: context,
                resource: "/graphql",
                path: "/graphql",
                httpMethod: "POST",
                headers: {
                    "Accept": "*/*",
                    "content-type": "application/json",
                },
            });
            break;
        case event.path === paths.graphQL:
            newEvent = event;
        default:
            break;
    }
    ;
    return apolloHandler(newEvent, context, callback);
};
exports.graphqlHandler = graphqlHandler;


/***/ }),

/***/ 575:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_datasource_rest_1 = __webpack_require__(797);
const basePath = "l94gia19j0.execute-api.us-east-1.amazonaws.com/prod";
class EstablishmentDB extends apollo_datasource_rest_1.RESTDataSource {
    constructor() {
        super();
        this.baseURL = `https://${basePath}/`;
    }
    willSendRequest(request) {
        request.headers.set("Accept", "*/*");
        request.headers.set("content-type", "application/json");
    }
    getEstablishment(dba_name) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('dba_name: ', dba_name);
            return yield this.get(`establishment?dba_name=${encodeURIComponent(dba_name)}`);
        });
    }
    createEstablishment(establishment) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('establishment: ', establishment);
            const postRes = yield this.post("establishment", establishment);
            console.log('postRes: ', postRes);
            return postRes.Item;
        });
    }
}
exports["default"] = EstablishmentDB;


/***/ }),

/***/ 981:
/***/ (function(__unused_webpack_module, exports) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolvers = void 0;
exports.resolvers = {
    Query: {
        getEstablishment: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            console.log('args: ', args);
            return yield context.dataSources.establishmentsDB.getEstablishment(args.dba_name);
        }),
        getEstablishments: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            return yield context.dataSources.establishmentsDB.getEstablishments();
        }),
    },
    Mutation: {
        createEstablishment: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            console.log('args: ', args);
            return yield context.dataSources.establishmentsDB.createEstablishment(args.establishment);
        })
    }
};


/***/ }),

/***/ 422:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.typeDefs = void 0;
const apollo_server_lambda_1 = __webpack_require__(270);
exports.typeDefs = (0, apollo_server_lambda_1.gql) `
  type Address {
    address_id: Int!,
    address_type: String!,
    address_state: String!
  }
  input AddressInput {
    address_id: Int!,
    address_type: String!,
    address_state: String!
  }
  type Establishment {
    dba_name: String!,
    legal_name: String!,
    addresses: [Address]
  }
  input EstablishmentInput {
    dba_name: String!,
    legal_name: String!,
    addresses: [AddressInput]
  }
  scalar Json
  type Query {
    testMessage: String!,
    getEstablishment(dba_name: String!): Establishment,
    getEstablishments: [Establishment],
  }
  type Mutation {
    createEstablishment(establishment: EstablishmentInput): Establishment
  }
`;


/***/ }),

/***/ 797:
/***/ ((module) => {

module.exports = require("apollo-datasource-rest");

/***/ }),

/***/ 270:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(625);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2Fwb2xsby1zZXJ2ZXIuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUFBO0FBSUE7QUFHQTtBQUlBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUFZQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUFXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBOUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkRBO0FBRUE7QUFFQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBSUE7QUFFQTs7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUVBOztBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDaEJBO0FBdUJBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE4QkE7Ozs7Ozs7O0FDckRBOzs7Ozs7O0FDQUE7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FFdkJBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci8uL3NyYy9hcG9sbG8tc2VydmVyLnRzIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvLi9zcmMvZGF0YXNvdXJjZXMvZXN0YWJsaXNobWVudHNEQi50cyIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyLy4vc3JjL3Jlc29sdmVycy50cyIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyLy4vc3JjL3R5cGUtZGVmcy50cyIsIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyL2V4dGVybmFsIGNvbW1vbmpzIFwiYXBvbGxvLWRhdGFzb3VyY2UtcmVzdFwiIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvZXh0ZXJuYWwgY29tbW9uanMgXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci93ZWJwYWNrL2JlZm9yZS1zdGFydHVwIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvd2VicGFjay9hZnRlci1zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gICAgQXBvbGxvU2VydmVyXG59IGZyb20gXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiO1xuXG5pbXBvcnQge1xuICAgIHJlc29sdmVyc1xufSBmcm9tIFwiLi9yZXNvbHZlcnNcIjtcbmltcG9ydCB7XG4gICAgdHlwZURlZnNcbn0gZnJvbSBcIi4vdHlwZS1kZWZzXCI7XG5cbmltcG9ydCBFc3RhYmxpc2htZW50c0RCIGZyb20gXCIuL2RhdGFzb3VyY2VzL2VzdGFibGlzaG1lbnRzREJcIjtcblxuY29uc3QgcGF0aHMgPSB7XG4gICAgZ3JhcGhRTDogXCIvZ3JhcGhxbFwiLFxuICAgIGVzdGFibGlzaG1lbnQ6IFwiL2VzdGFibGlzaG1lbnRcIixcbn07XG5cbmNvbnN0IGFwb2xsb1NlcnZlciA9IG5ldyBBcG9sbG9TZXJ2ZXIoe1xuICAgIHJlc29sdmVycyxcbiAgICB0eXBlRGVmcyxcbiAgICBjb250ZXh0OiAoe1xuICAgICAgICBldmVudCxcbiAgICAgICAgY29udGV4dFxuICAgIH0pID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coXCJzZXJ2ZXIgZXZlbnQ6IFwiLCBldmVudCk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwic2VydmVyIGNvbnRleHQ6IFwiLCBjb250ZXh0KTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGhlYWRlcnM6IGV2ZW50LmhlYWRlcnMsXG4gICAgICAgICAgICBmdW5jdGlvbk5hbWU6IGNvbnRleHQuZnVuY3Rpb25OYW1lLFxuICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICB9O1xuICAgIH0sXG4gICAgZGF0YVNvdXJjZXM6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGVzdGFibGlzaG1lbnRzREI6IG5ldyBFc3RhYmxpc2htZW50c0RCKCksXG4gICAgICAgIH07XG4gICAgfSxcbiAgICBpbnRyb3NwZWN0aW9uOiB0cnVlLFxufSk7XG5cbmNvbnN0IGFwb2xsb0hhbmRsZXIgPSBhcG9sbG9TZXJ2ZXIuY3JlYXRlSGFuZGxlcih7XG4gICAgZXhwcmVzc0dldE1pZGRsZXdhcmVPcHRpb25zOiB7XG4gICAgICAgIGNvcnM6IHtcbiAgICAgICAgICAgIG9yaWdpbjogXCIqXCIsXG4gICAgICAgICAgICBjcmVkZW50aWFsczogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBncmFwaHFsSGFuZGxlciA9IChldmVudDogYW55LCBjb250ZXh0OiBhbnksIGNhbGxiYWNrOiBhbnkpID0+IHtcbiAgICBjb25zb2xlLmxvZyhcIlJlcXVlc3QgZXZlbnRcIiwgZXZlbnQpO1xuICAgIGNvbnNvbGUubG9nKFwiUmVxdWVzdCBjb250ZXh0OiBcIiwgY29udGV4dCk7XG4gICAgXG4gICAgbGV0IHJlc0JvZHksIHZhcmlhYmxlcywgbmV3RXZlbnQ7XG4gICAgc3dpdGNoICh0cnVlKSB7XG4gICAgICAgIGNhc2UgZXZlbnQuaHR0cE1ldGhvZCA9PT0gXCJHRVRcIiAmJiBldmVudC5wYXRoID09PSBwYXRocy5lc3RhYmxpc2htZW50OlxuICAgICAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgICAgICAgICAgcXVlcnkgR2V0RXN0YWJsaXNobWVudCgkZ2V0RXN0YWJsaXNobWVudElkOiBTdHJpbmchKSB7XG4gICAgICAgICAgICAgICAgICAgIGdldEVzdGFibGlzaG1lbnQoZGJhX25hbWU6ICRnZXRFc3RhYmxpc2htZW50SWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRiYV9uYW1lXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWdhbF9uYW1lXG4gICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzZXMge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3NfaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzX3R5cGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzX3N0YXRlXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYDtcbiAgICAgICAgICAgIHZhcmlhYmxlcyA9IHtcbiAgICAgICAgICAgICAgICBnZXRFc3RhYmxpc2htZW50SWQ6IGV2ZW50LnF1ZXJ5U3RyaW5nUGFyYW1ldGVycy5kYmFfbmFtZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICByZXNCb2R5ID0gSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgbmV3RXZlbnQgPSBPYmplY3QuYXNzaWduKGV2ZW50LCB7XG4gICAgICAgICAgICAgICAgYm9keTogcmVzQm9keSxcbiAgICAgICAgICAgICAgICByZXF1ZXN0Q29udGV4dDogY29udGV4dCxcbiAgICAgICAgICAgICAgICByZXNvdXJjZTogXCIvZ3JhcGhxbFwiLFxuICAgICAgICAgICAgICAgIHBhdGg6IFwiL2dyYXBocWxcIixcbiAgICAgICAgICAgICAgICBodHRwTWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgIFwiQWNjZXB0XCI6IFwiKi8qXCIsXG4gICAgICAgICAgICAgICAgICAgIFwiY29udGVudC10eXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIGV2ZW50Lmh0dHBNZXRob2QgPT09IFwiUE9TVFwiICYmIGV2ZW50LnBhdGggPT09IHBhdGhzLmVzdGFibGlzaG1lbnQ6XG4gICAgICAgICAgICBjb25zdCBtdXRhdGlvbiA9IGBcbiAgICAgICAgICAgICAgICBtdXRhdGlvbiBDcmVhdGVFc3RhYmxpc2htZW50KCRuZXdFc3RhYmxpc2htZW50OiBFc3RhYmxpc2htZW50SW5wdXQpIHtcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlRXN0YWJsaXNobWVudChlc3RhYmxpc2htZW50OiAkbmV3RXN0YWJsaXNobWVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGJhX25hbWVcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlZ2FsX25hbWVcbiAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3NlcyB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzc19pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3NfdHlwZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3Nfc3RhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1gO1xuICAgICAgICAgICAgY29uc3QgYm9keSA9IEpTT04ucGFyc2UoZXZlbnQuYm9keSk7XG4gICAgICAgICAgICB2YXJpYWJsZXMgPSB7XG4gICAgICAgICAgICAgICAgbmV3RXN0YWJsaXNobWVudDogYm9keVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHJlc0JvZHkgPSBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgcXVlcnk6IG11dGF0aW9uLFxuICAgICAgICAgICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgbmV3RXZlbnQgPSBPYmplY3QuYXNzaWduKGV2ZW50LCB7XG4gICAgICAgICAgICAgICAgYm9keTogcmVzQm9keSxcbiAgICAgICAgICAgICAgICByZXF1ZXN0Q29udGV4dDogY29udGV4dCxcbiAgICAgICAgICAgICAgICByZXNvdXJjZTogXCIvZ3JhcGhxbFwiLFxuICAgICAgICAgICAgICAgIHBhdGg6IFwiL2dyYXBocWxcIixcbiAgICAgICAgICAgICAgICBodHRwTWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgIFwiQWNjZXB0XCI6IFwiKi8qXCIsXG4gICAgICAgICAgICAgICAgICAgIFwiY29udGVudC10eXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIGV2ZW50LnBhdGggPT09IHBhdGhzLmdyYXBoUUw6XG4gICAgICAgICAgICBuZXdFdmVudCA9IGV2ZW50O1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgYnJlYWs7XG4gICAgfTtcbiAgICByZXR1cm4gYXBvbGxvSGFuZGxlcihuZXdFdmVudCwgY29udGV4dCwgY2FsbGJhY2spO1xufTsiLCJpbXBvcnQgeyBSRVNURGF0YVNvdXJjZSwgUmVxdWVzdE9wdGlvbnMgfSBmcm9tIFwiYXBvbGxvLWRhdGFzb3VyY2UtcmVzdFwiO1xuXG5jb25zdCBiYXNlUGF0aCA9IFwibDk0Z2lhMTlqMC5leGVjdXRlLWFwaS51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9wcm9kXCI7XG5cbmNsYXNzIEVzdGFibGlzaG1lbnREQiBleHRlbmRzIFJFU1REYXRhU291cmNlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLy8gQWx3YXlzIGNhbGwgc3VwZXIoKVxuICAgIHN1cGVyKCk7XG4gICAgLy8gU2V0cyB0aGUgYmFzZSBVUkwgZm9yIHRoZSBSRVNUIEFQSVxuICAgIHRoaXMuYmFzZVVSTCA9IGBodHRwczovLyR7YmFzZVBhdGh9L2A7XG4gIH1cbiAgd2lsbFNlbmRSZXF1ZXN0KHJlcXVlc3Q6IFJlcXVlc3RPcHRpb25zKSB7XG4gICAgcmVxdWVzdC5oZWFkZXJzLnNldChcbiAgICAgIFwiQWNjZXB0XCIsXG4gICAgICBcIiovKlwiXG4gICAgKTtcbiAgICByZXF1ZXN0LmhlYWRlcnMuc2V0KFxuICAgICAgXCJjb250ZW50LXR5cGVcIixcbiAgICAgIFwiYXBwbGljYXRpb24vanNvblwiXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIGdldEVzdGFibGlzaG1lbnQoZGJhX25hbWU6IHN0cmluZykge1xuICAgIGNvbnNvbGUubG9nKCdkYmFfbmFtZTogJywgZGJhX25hbWUpO1xuICAgIHJldHVybiBhd2FpdCB0aGlzLmdldChgZXN0YWJsaXNobWVudD9kYmFfbmFtZT0ke2VuY29kZVVSSUNvbXBvbmVudChkYmFfbmFtZSl9YCk7XG4gIH1cblxuICBhc3luYyBjcmVhdGVFc3RhYmxpc2htZW50KGVzdGFibGlzaG1lbnQ6IGFueSkge1xuICAgIGNvbnNvbGUubG9nKCdlc3RhYmxpc2htZW50OiAnLCBlc3RhYmxpc2htZW50KTtcbiAgICAgIGNvbnN0IHBvc3RSZXMgPSBhd2FpdCB0aGlzLnBvc3QoXG4gICAgICAgICAgXCJlc3RhYmxpc2htZW50XCIsXG4gICAgICAgICAgZXN0YWJsaXNobWVudFxuICAgICAgICApXG4gICAgY29uc29sZS5sb2coJ3Bvc3RSZXM6ICcsIHBvc3RSZXMpO1xuICAgIHJldHVybiBwb3N0UmVzLkl0ZW07XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgRXN0YWJsaXNobWVudERCO1xuIiwiZXhwb3J0IGNvbnN0IHJlc29sdmVycyA9IHtcbiAgUXVlcnk6IHtcbiAgICBnZXRFc3RhYmxpc2htZW50OiBhc3luYyAocGFyZW50OiBhbnksIGFyZ3M6IGFueSwgY29udGV4dDogYW55LCBpbmZvOiBhbnkpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKCdhcmdzOiAnLCBhcmdzKTtcbiAgICAgIHJldHVybiBhd2FpdCBjb250ZXh0LmRhdGFTb3VyY2VzLmVzdGFibGlzaG1lbnRzREIuZ2V0RXN0YWJsaXNobWVudChhcmdzLmRiYV9uYW1lKTtcbiAgICB9LFxuICAgIGdldEVzdGFibGlzaG1lbnRzOiBhc3luYyAocGFyZW50OiBhbnksIGFyZ3M6IGFueSwgY29udGV4dDogYW55LCBpbmZvOiBhbnkpID0+IHtcbiAgICAgIHJldHVybiBhd2FpdCBjb250ZXh0LmRhdGFTb3VyY2VzLmVzdGFibGlzaG1lbnRzREIuZ2V0RXN0YWJsaXNobWVudHMoKTtcbiAgICB9LFxuICB9LFxuICBNdXRhdGlvbjoge1xuICAgIGNyZWF0ZUVzdGFibGlzaG1lbnQ6IGFzeW5jIChwYXJlbnQ6IGFueSwgYXJnczogYW55LCBjb250ZXh0OiBhbnksIGluZm86IGFueSkgPT4ge1xuICAgICAgY29uc29sZS5sb2coJ2FyZ3M6ICcsIGFyZ3MpO1xuICAgICAgcmV0dXJuIGF3YWl0IGNvbnRleHQuZGF0YVNvdXJjZXMuZXN0YWJsaXNobWVudHNEQi5jcmVhdGVFc3RhYmxpc2htZW50KGFyZ3MuZXN0YWJsaXNobWVudCk7XG4gICAgfVxuICB9XG59OyIsImltcG9ydCB7IGdxbCB9IGZyb20gXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiO1xuXG4vLyB7XG4vLyAgIFwiZXN0YWJsaXNobWVudHNcIjogW1xuICAgIC8vIHtcbiAgICAvLyAgIFwiZGJhX25hbWVcIjogXCJFc3QxXCIsXG4gICAgLy8gICBcImxlZ2FsX25hbWVcIjogXCJFc3QxXCIsXG4gICAgLy8gICBcImFkZHJlc3Nlc1wiOiBbXG4gICAgLy8gICAgIHtcbiAgICAvLyAgICAgICBcImFkZHJlc3NfaWRcIjogMSxcbiAgICAvLyAgICAgICBcImFkZHJlc3NfdHlwZVwiOiBcIm9mZmljZVwiLFxuICAgIC8vICAgICAgIFwiYWRkcmVzc19zdGF0ZVwiOiBcIlZBXCJcbiAgICAvLyAgICAgfSxcbiAgICAvLyAgICAge1xuICAgIC8vICAgICAgIFwiYWRkcmVzc19pZFwiOiAyLFxuICAgIC8vICAgICAgIFwiYWRkcmVzc190eXBlXCI6IFwicGh5c2ljYWwgbG9jYXRpb25cIixcbiAgICAvLyAgICAgICBcImFkZHJlc3Nfc3RhdGVcIjogXCJWQVwiXG4gICAgLy8gICAgIH1cbiAgICAvLyAgIF1cbiAgICAvLyB9XG4vLyAgIF1cbi8vIH1cblxuZXhwb3J0IGNvbnN0IHR5cGVEZWZzID0gZ3FsYFxuICB0eXBlIEFkZHJlc3Mge1xuICAgIGFkZHJlc3NfaWQ6IEludCEsXG4gICAgYWRkcmVzc190eXBlOiBTdHJpbmchLFxuICAgIGFkZHJlc3Nfc3RhdGU6IFN0cmluZyFcbiAgfVxuICBpbnB1dCBBZGRyZXNzSW5wdXQge1xuICAgIGFkZHJlc3NfaWQ6IEludCEsXG4gICAgYWRkcmVzc190eXBlOiBTdHJpbmchLFxuICAgIGFkZHJlc3Nfc3RhdGU6IFN0cmluZyFcbiAgfVxuICB0eXBlIEVzdGFibGlzaG1lbnQge1xuICAgIGRiYV9uYW1lOiBTdHJpbmchLFxuICAgIGxlZ2FsX25hbWU6IFN0cmluZyEsXG4gICAgYWRkcmVzc2VzOiBbQWRkcmVzc11cbiAgfVxuICBpbnB1dCBFc3RhYmxpc2htZW50SW5wdXQge1xuICAgIGRiYV9uYW1lOiBTdHJpbmchLFxuICAgIGxlZ2FsX25hbWU6IFN0cmluZyEsXG4gICAgYWRkcmVzc2VzOiBbQWRkcmVzc0lucHV0XVxuICB9XG4gIHNjYWxhciBKc29uXG4gIHR5cGUgUXVlcnkge1xuICAgIHRlc3RNZXNzYWdlOiBTdHJpbmchLFxuICAgIGdldEVzdGFibGlzaG1lbnQoZGJhX25hbWU6IFN0cmluZyEpOiBFc3RhYmxpc2htZW50LFxuICAgIGdldEVzdGFibGlzaG1lbnRzOiBbRXN0YWJsaXNobWVudF0sXG4gIH1cbiAgdHlwZSBNdXRhdGlvbiB7XG4gICAgY3JlYXRlRXN0YWJsaXNobWVudChlc3RhYmxpc2htZW50OiBFc3RhYmxpc2htZW50SW5wdXQpOiBFc3RhYmxpc2htZW50XG4gIH1cbmA7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhcG9sbG8tZGF0YXNvdXJjZS1yZXN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIpOyIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIiLCIvLyBzdGFydHVwXG4vLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbi8vIFRoaXMgZW50cnkgbW9kdWxlIGlzIHJlZmVyZW5jZWQgYnkgb3RoZXIgbW9kdWxlcyBzbyBpdCBjYW4ndCBiZSBpbmxpbmVkXG52YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18oNjI1KTtcbiIsIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==