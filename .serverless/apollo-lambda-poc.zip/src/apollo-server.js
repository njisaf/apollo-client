/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 625:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(270);
const dynamodb_1 = __webpack_require__(417);
const resolvers_1 = __webpack_require__(981);
const type_defs_1 = __webpack_require__(422);
const establishmentsDB_1 = __importDefault(__webpack_require__(575));
const client = new dynamodb_1.DocumentClient({
    apiVersion: 'latest',
    region: 'us-east-1',
});
const apolloServer = new apollo_server_lambda_1.ApolloServer({
    resolvers: resolvers_1.resolvers,
    typeDefs: type_defs_1.typeDefs,
    context: ({ event, context }) => {
        console.log('event: ', event);
        console.log('context: ', context);
        return {
            headers: event.headers,
            functionName: context.functionName,
            event,
            context
        };
    },
    dataSources: () => {
        return {
            establishmentsDB: new establishmentsDB_1.default(client)
        };
    }
});
exports.graphqlHandler = apolloServer.createHandler({
    expressGetMiddlewareOptions: {
        cors: {
            origin: '*',
            credentials: true,
        },
    },
});


/***/ }),

/***/ 575:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_datasource_dynamodb_1 = __webpack_require__(628);
const tableName = "establishments";
const tableKeySchema = [
    {
        AttributeName: "id",
        KeyType: "HASH",
    },
];
class EstablishmentsDB extends apollo_datasource_dynamodb_1.DynamoDBDataSource {
    constructor(client) {
        super(tableName, tableKeySchema, undefined, client);
        this.ttl = 30 * 60;
    }
    getEstablishment(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const getItemInput = {
                TableName: tableName,
                ConsistentRead: true,
                Key: { id },
            };
            return this.getItem(getItemInput, this.ttl);
        });
    }
    getAllEstablishments() {
        return __awaiter(this, void 0, void 0, function* () {
            const scanInput = {
                TableName: tableName,
                ConsistentRead: true,
            };
            return this.scan(scanInput, this.ttl);
        });
    }
}
exports["default"] = EstablishmentsDB;


/***/ }),

/***/ 824:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.environment = void 0;
exports.environment = {
    secretMessage: process.env.SECRET_MESSAGE,
    apiToken: process.env.API_TOKEN,
};


/***/ }),

/***/ 981:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolvers = void 0;
const environment_1 = __webpack_require__(824);
exports.resolvers = {
    Query: {
        testMessage: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            return `${environment_1.environment.secretMessage}. Your message is ${args.search}`;
        }),
        getEstablishment: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            return context.dataSources.establishmentsDB.getEstablishment(args.id);
        }),
        getAllEstablishments: (parent, args, context, info) => __awaiter(void 0, void 0, void 0, function* () {
            return context.dataSources.establishmentsDB.getAllEstablishments();
        }),
    },
};


/***/ }),

/***/ 422:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.typeDefs = void 0;
const apollo_server_lambda_1 = __webpack_require__(270);
exports.typeDefs = (0, apollo_server_lambda_1.gql) `
  type Establishment {
    id: String!,
    name: String!
  }
  scalar Json
  type Query {
    testMessage: String!,
    getEstablishment(id: String!): Establishment,
    getAllEstablishments: [Establishment]
  }
`;


/***/ }),

/***/ 628:
/***/ ((module) => {

module.exports = require("apollo-datasource-dynamodb");

/***/ }),

/***/ 270:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");

/***/ }),

/***/ 417:
/***/ ((module) => {

module.exports = require("aws-sdk/clients/dynamodb");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(625);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2Fwb2xsby1zZXJ2ZXIuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlDQTtBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFJQTtBQUNBO0FBSEE7QUFJQTtBQUVBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFFQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQVNBO0FBRUE7Ozs7Ozs7Ozs7O0FDN0NBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1JBO0FBeUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ3JDQTtBQUVBOzs7Ozs7Ozs7OztBQVdBOzs7Ozs7OztBQ2JBOzs7Ozs7O0FDQUE7Ozs7Ozs7QUNBQTs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUV2QkE7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcG9sbG8tc2VydmVyLy4vc3JjL2Fwb2xsby1zZXJ2ZXIudHMiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci8uL3NyYy9kYXRhc291cmNlcy9lc3RhYmxpc2htZW50c0RCLnRzIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvLi9zcmMvZW52aXJvbm1lbnQudHMiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci8uL3NyYy9yZXNvbHZlcnMudHMiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci8uL3NyYy90eXBlLWRlZnMudHMiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci9leHRlcm5hbCBjb21tb25qcyBcImFwb2xsby1kYXRhc291cmNlLWR5bmFtb2RiXCIiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci9leHRlcm5hbCBjb21tb25qcyBcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci9leHRlcm5hbCBjb21tb25qcyBcImF3cy1zZGsvY2xpZW50cy9keW5hbW9kYlwiIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vYXBvbGxvLXNlcnZlci93ZWJwYWNrL2JlZm9yZS1zdGFydHVwIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL2Fwb2xsby1zZXJ2ZXIvd2VicGFjay9hZnRlci1zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbIlxuaW1wb3J0IHsgQXBvbGxvU2VydmVyIH0gZnJvbSAnYXBvbGxvLXNlcnZlci1sYW1iZGEnO1xuaW1wb3J0IHsgRG9jdW1lbnRDbGllbnQgfSBmcm9tICdhd3Mtc2RrL2NsaWVudHMvZHluYW1vZGInO1xuXG5pbXBvcnQgeyByZXNvbHZlcnMgfSBmcm9tICcuL3Jlc29sdmVycyc7XG5pbXBvcnQgeyB0eXBlRGVmcyB9IGZyb20gJy4vdHlwZS1kZWZzJztcblxuaW1wb3J0IEVzdGFibGlzaG1lbnRzREIgZnJvbSAnLi9kYXRhc291cmNlcy9lc3RhYmxpc2htZW50c0RCJztcbi8vIGltcG9ydCBNb3ZpZXNBUEkgZnJvbSAnLi9kYXRhc291cmNlcy9tb3ZpZXNBUEknO1xuLy8gaW1wb3J0IEltZGJBUEkgZnJvbSAnLi9kYXRhc291cmNlcy9pbWRiQVBJJztcblxuY29uc3QgY2xpZW50OiBEb2N1bWVudENsaWVudCA9IG5ldyBEb2N1bWVudENsaWVudCh7XG4gICAgYXBpVmVyc2lvbjogJ2xhdGVzdCcsXG4gICAgcmVnaW9uOiAndXMtZWFzdC0xJyxcbn0pO1xuXG5cbmNvbnN0IGFwb2xsb1NlcnZlciA9IG5ldyBBcG9sbG9TZXJ2ZXIoe1xuICAgIHJlc29sdmVycyxcbiAgICB0eXBlRGVmcyxcbiAgICBjb250ZXh0OiAoe2V2ZW50LCBjb250ZXh0fSkgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZygnZXZlbnQ6ICcsIGV2ZW50KTtcbiAgICAgICAgY29uc29sZS5sb2coJ2NvbnRleHQ6ICcsIGNvbnRleHQpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGVhZGVyczogZXZlbnQuaGVhZGVycyxcbiAgICAgICAgICAgIGZ1bmN0aW9uTmFtZTogY29udGV4dC5mdW5jdGlvbk5hbWUsXG4gICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgIGNvbnRleHRcbiAgICAgICAgfVxuICAgIH0sXG4gICAgZGF0YVNvdXJjZXM6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC8vIG1vdmllc0FQSTogbmV3IE1vdmllc0FQSSgpLFxuICAgICAgICAgICAgLy8gaW1kYkFQSTogbmV3IEltZGJBUEkoKSxcbiAgICAgICAgICAgIGVzdGFibGlzaG1lbnRzREI6IG5ldyBFc3RhYmxpc2htZW50c0RCKGNsaWVudClcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuXG5leHBvcnQgY29uc3QgZ3JhcGhxbEhhbmRsZXIgPSBhcG9sbG9TZXJ2ZXIuY3JlYXRlSGFuZGxlcih7XG4gICAgZXhwcmVzc0dldE1pZGRsZXdhcmVPcHRpb25zOiB7XG4gICAgICAgIGNvcnM6IHtcbiAgICAgICAgICAgIG9yaWdpbjogJyonLFxuICAgICAgICAgICAgY3JlZGVudGlhbHM6IHRydWUsXG4gICAgICAgIH0sXG4gICAgfSxcbn0pOyIsImltcG9ydCB7IER5bmFtb0RCRGF0YVNvdXJjZSB9IGZyb20gXCJhcG9sbG8tZGF0YXNvdXJjZS1keW5hbW9kYlwiO1xuaW1wb3J0IHsgRG9jdW1lbnRDbGllbnQgfSBmcm9tIFwiYXdzLXNkay9jbGllbnRzL2R5bmFtb2RiXCI7XG5cbnR5cGUgRXN0YWJsaXNobWVudCA9IHtcbiAgICBpZDogbnVtYmVyLFxuICAgIG5hbWU6IHN0cmluZ1xufVxuXG5jb25zdCB0YWJsZU5hbWUgPSBcImVzdGFibGlzaG1lbnRzXCI7XG5jb25zdCB0YWJsZUtleVNjaGVtYTogRG9jdW1lbnRDbGllbnQuS2V5U2NoZW1hID0gW1xuICAgIHtcbiAgICAgICAgQXR0cmlidXRlTmFtZTogXCJpZFwiLFxuICAgICAgICBLZXlUeXBlOiBcIkhBU0hcIixcbiAgICB9LFxuXTtcblxuY2xhc3MgRXN0YWJsaXNobWVudHNEQiBleHRlbmRzIER5bmFtb0RCRGF0YVNvdXJjZTxFc3RhYmxpc2htZW50PiB7XG5cbiAgcHJpdmF0ZSByZWFkb25seSB0dGwgPSAzMCAqIDYwOyAvLyAzMG1pbnV0ZXNcblxuICBjb25zdHJ1Y3RvcihjbGllbnQ/OiBEb2N1bWVudENsaWVudCkge1xuICAgIHN1cGVyKHRhYmxlTmFtZSwgdGFibGVLZXlTY2hlbWEsIHVuZGVmaW5lZCwgY2xpZW50KTtcbiAgfVxuXG4gIGFzeW5jIGdldEVzdGFibGlzaG1lbnQoaWQ6IHN0cmluZyk6IFByb21pc2U8RXN0YWJsaXNobWVudD4ge1xuICAgIGNvbnN0IGdldEl0ZW1JbnB1dDogRG9jdW1lbnRDbGllbnQuR2V0SXRlbUlucHV0ID0ge1xuICAgICAgVGFibGVOYW1lOiB0YWJsZU5hbWUsXG4gICAgICBDb25zaXN0ZW50UmVhZDogdHJ1ZSxcbiAgICAgIEtleTogeyBpZCB9LFxuICAgIH07XG4gICAgcmV0dXJuIHRoaXMuZ2V0SXRlbShnZXRJdGVtSW5wdXQsIHRoaXMudHRsKTtcbiAgfVxuXG4gIGFzeW5jIGdldEFsbEVzdGFibGlzaG1lbnRzKCk6IFByb21pc2U8RXN0YWJsaXNobWVudFtdPiB7XG4gICAgY29uc3Qgc2NhbklucHV0OiBEb2N1bWVudENsaWVudC5TY2FuSW5wdXQgPSB7XG4gICAgICBUYWJsZU5hbWU6IHRhYmxlTmFtZSxcbiAgICAgIENvbnNpc3RlbnRSZWFkOiB0cnVlLFxuICAgIH07XG4gICAgcmV0dXJuIHRoaXMuc2NhbihzY2FuSW5wdXQsIHRoaXMudHRsKTtcbiAgfVxuXG4vLyAgIGFzeW5jIGNyZWF0ZUVzdGFibGlzaG1lbnQoaWQ6IG51bWJlciwgbmFtZTogc3RyaW5nKTogUHJvbWlzZTxFc3RhYmxpc2htZW50PiB7XG4vLyAgICAgICBjb25zdCBuZXdFc3RhYmxpc2htZW50OiBFc3RhYmxpc2htZW50ID0ge1xuLy8gICAgICAgICBpZCxcbi8vICAgICAgICAgbmFtZVxuLy8gICAgICAgfTtcblxuLy8gICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IEVzdGFibGlzaG1lbnRzREI7XG4iLCJ0eXBlIEVudmlyb25tZW50ID0ge1xuICAgIHNlY3JldE1lc3NhZ2U6IHN0cmluZyxcbiAgICBhcGlUb2tlbjogc3RyaW5nXG59O1xuXG5leHBvcnQgY29uc3QgZW52aXJvbm1lbnQ6IEVudmlyb25tZW50ID0ge1xuICAgIHNlY3JldE1lc3NhZ2U6IHByb2Nlc3MuZW52LlNFQ1JFVF9NRVNTQUdFIGFzIHN0cmluZyxcbiAgICBhcGlUb2tlbjogcHJvY2Vzcy5lbnYuQVBJX1RPS0VOIGFzIHN0cmluZyxcbn07IiwiaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICcuL2Vudmlyb25tZW50Jztcbi8vIGltcG9ydCB7IHVubWFyc2hhbGwgfSBmcm9tIFwiQGF3cy1zZGsvdXRpbC1keW5hbW9kYlwiO1xuLy8gaW1wb3J0IHsgRHluYW1vREJDbGllbnQsIFNjYW5Db21tYW5kIH0gZnJvbSBcIkBhd3Mtc2RrL2NsaWVudC1keW5hbW9kYlwiO1xuXG4vLyBjb25zdCBjbGllbnQgPSBuZXcgRHluYW1vREJDbGllbnQoeyByZWdpb246IFwidXMtZWFzdC0xXCIgfSk7XG5cbi8vIGNvbnN0IGdldEhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XG4vLyAgIGNvbnN0IHBhcmFtcyA9IHtcbi8vICAgICBUYWJsZU5hbWU6IFwic2VhcmNoX2hpc3RvcnlcIixcbi8vICAgfTtcblxuLy8gICB0cnkge1xuLy8gICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBjbGllbnQuc2VuZChuZXcgU2NhbkNvbW1hbmQocGFyYW1zKSk7XG4vLyAgICAgY29uc3QgaGlzdG9yeTogYW55ID0gW107XG4vLyAgICAgcmVzdWx0cz8uSXRlbXM/LmZvckVhY2goKGl0ZW0pID0+IHtcbi8vICAgICAgIGhpc3RvcnkucHVzaCh1bm1hcnNoYWxsKGl0ZW0pKTtcbi8vICAgICB9KTtcbi8vICAgICBjb25zb2xlLmxvZygnaGlzdG9yeTogJywgaGlzdG9yeSk7XG4vLyAgICAgcmV0dXJuIGhpc3Rvcnk7XG4vLyAgIH0gY2F0Y2ggKGVycikge1xuLy8gICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbi8vICAgICByZXR1cm4gZXJyO1xuLy8gICB9XG4vLyB9O1xuXG5leHBvcnQgY29uc3QgcmVzb2x2ZXJzID0ge1xuICBRdWVyeToge1xuICAgIHRlc3RNZXNzYWdlOiBhc3luYyAocGFyZW50OiBhbnksIGFyZ3M6IGFueSwgY29udGV4dDogYW55LCBpbmZvOiBhbnkpID0+IHtcbiAgICAgIHJldHVybiBgJHtlbnZpcm9ubWVudC5zZWNyZXRNZXNzYWdlfS4gWW91ciBtZXNzYWdlIGlzICR7YXJncy5zZWFyY2h9YDtcbiAgICB9LFxuICAgIGdldEVzdGFibGlzaG1lbnQ6IGFzeW5jIChwYXJlbnQ6IGFueSwgYXJnczogYW55LCBjb250ZXh0OiBhbnksIGluZm86IGFueSkgPT4ge1xuICAgICAgcmV0dXJuIGNvbnRleHQuZGF0YVNvdXJjZXMuZXN0YWJsaXNobWVudHNEQi5nZXRFc3RhYmxpc2htZW50KGFyZ3MuaWQpO1xuICAgIH0sXG4gICAgZ2V0QWxsRXN0YWJsaXNobWVudHM6IGFzeW5jIChwYXJlbnQ6IGFueSwgYXJnczogYW55LCBjb250ZXh0OiBhbnksIGluZm86IGFueSkgPT4ge1xuICAgICAgcmV0dXJuIGNvbnRleHQuZGF0YVNvdXJjZXMuZXN0YWJsaXNobWVudHNEQi5nZXRBbGxFc3RhYmxpc2htZW50cygpO1xuICAgIH0sXG4gIH0sXG59OyIsImltcG9ydCB7IGdxbCB9IGZyb20gXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiO1xuXG5leHBvcnQgY29uc3QgdHlwZURlZnMgPSBncWxgXG4gIHR5cGUgRXN0YWJsaXNobWVudCB7XG4gICAgaWQ6IFN0cmluZyEsXG4gICAgbmFtZTogU3RyaW5nIVxuICB9XG4gIHNjYWxhciBKc29uXG4gIHR5cGUgUXVlcnkge1xuICAgIHRlc3RNZXNzYWdlOiBTdHJpbmchLFxuICAgIGdldEVzdGFibGlzaG1lbnQoaWQ6IFN0cmluZyEpOiBFc3RhYmxpc2htZW50LFxuICAgIGdldEFsbEVzdGFibGlzaG1lbnRzOiBbRXN0YWJsaXNobWVudF1cbiAgfVxuYDtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImFwb2xsby1kYXRhc291cmNlLWR5bmFtb2RiXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImF3cy1zZGsvY2xpZW50cy9keW5hbW9kYlwiKTsiLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBpcyByZWZlcmVuY2VkIGJ5IG90aGVyIG1vZHVsZXMgc28gaXQgY2FuJ3QgYmUgaW5saW5lZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDYyNSk7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=