
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'njisaf',
  applicationName: 'apollo-server',
  appUid: 'M03Xs74gYb38QGc2rR',
  orgUid: 'st4Fgp6YKSrWq3KrBy',
  deploymentUid: '18504731-1cb8-4e8b-a96e-4833b012c3aa',
  serviceName: 'apollo-lambda-poc',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-poc-prod-graphql', timeout: 6 };

try {
  const userHandler = require('./src/apollo-server.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}