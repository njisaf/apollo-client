
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'njisaf',
  applicationName: 'apollo-server',
  appUid: 'M03Xs74gYb38QGc2rR',
  orgUid: 'st4Fgp6YKSrWq3KrBy',
  deploymentUid: 'c72f9674-24ca-4a1d-aba8-948ba3ccd984',
  serviceName: 'apollo-lambda-poc',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-poc-prod-graphql', timeout: 6 };

try {
  const userHandler = require('./src/apollo-server.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}