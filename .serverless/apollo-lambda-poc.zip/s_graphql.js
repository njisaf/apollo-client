
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'njisaf',
  applicationName: 'apollo-server',
  appUid: 'M03Xs74gYb38QGc2rR',
  orgUid: 'st4Fgp6YKSrWq3KrBy',
  deploymentUid: '9d05bc9b-49dc-40ac-ab07-c7172601d39a',
  serviceName: 'apollo-lambda-poc',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-poc-prod-graphql', timeout: 6 };

try {
  const userHandler = require('./src/apollo-server.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}